# RNWIS 0.1.8

- Update outdated URLs

- Add Makefile for automating package-development tasks.

- Change to in-source documentation using **roxygen2** package.

- Change NEWS file to markdown format.

- Change format for package version numbering from #.#-# to #.#.#
